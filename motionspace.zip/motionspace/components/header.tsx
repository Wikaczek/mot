'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Menu, X } from 'lucide-react'
import { motion } from 'framer-motion'

export function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="py-6">
      <nav className="flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold text-white">
          Motion<span className="text-blue-500">Space</span>
        </Link>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          {['Home', 'Team', 'Portfolio', 'Contact'].map((item) => (
            <Link
              key={item}
              href={
                item === 'Home' 
                  ? '/' 
                  : item === 'Team' 
                  ? '#team' 
                  : item === 'Contact'
                  ? 'https://discord.gg/motionspace'
                  : `/${item.toLowerCase()}`
              }
              target={item === 'Contact' ? '_blank' : '_self'}
              className="text-gray-300 hover:text-white transition-colors"
            >
              {item}
            </Link>
          ))}
        </div>

        {/* Mobile Navigation */}
        <button
          className="md:hidden text-white z-50 relative"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X /> : <Menu />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, x: '100%' }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: '100%' }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="md:hidden fixed top-0 right-0 w-full h-screen bg-gray-900 z-50"
        >
          <button
            className="absolute top-6 right-6 text-white"
            onClick={() => setIsOpen(false)}
          >
            <X size={24} />
          </button>
          <div className="flex flex-col p-6 space-y-6 mt-20">
            {['Home', 'Team', 'Portfolio', 'Contact'].map((item) => (
              <Link
                key={item}
                href={
                  item === 'Home' 
                    ? '/' 
                    : item === 'Team' 
                    ? '#team' 
                    : item === 'Contact'
                    ? 'https://discord.gg/motionspace'
                    : `/${item.toLowerCase()}`
                }
                target={item === 'Contact' ? '_blank' : '_self'}
                className="text-gray-300 hover:text-white transition-colors"
                onClick={() => setIsOpen(false)}
              >
                {item}
              </Link>
            ))}
          </div>
        </motion.div>
      )}
    </header>
  )
}

