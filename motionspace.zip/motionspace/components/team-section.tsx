'use client'

import { motion } from 'framer-motion'
import { TeamMember, teamMembers } from '@/data/team'
import { Card } from '@/components/ui/card'
import { DiscIcon as DiscordIcon, InstagramIcon, DribbbleIcon as BehanceIcon } from 'lucide-react'

interface TeamCardProps {
  member: TeamMember
  index: number
}

function TeamCard({ member, index }: TeamCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="overflow-hidden rounded-3xl bg-gray-900/50 backdrop-blur-lg border border-gray-800">
        <div className="p-6 flex flex-col items-center text-center space-y-4">
          {/* Profile Image */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }}
            className="relative w-24 h-24 mb-4 rounded-full overflow-hidden border-2 border-gray-700"
          >
            <img
              src={member.image}
              alt={member.name}
              className="w-full h-full object-cover"
            />
          </motion.div>

          {/* Name */}
          <h3 className="text-xl font-bold text-white">
            {member.name}
          </h3>

          {/* Role */}
          <p className="text-sm text-gray-400">
            {member.role}
          </p>

        </div>
      </Card>
    </motion.div>
  )
}

export function TeamSection() {
  return (
    <section id="team" className="py-20 overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-white mb-4">
            Nasz Zespół
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <TeamCard key={member.id} member={member} index={index} />
          ))}
        </div>
      </div>

      {/* Galaxy UI-inspired background elements */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
      </div>
    </section>
  )
}

