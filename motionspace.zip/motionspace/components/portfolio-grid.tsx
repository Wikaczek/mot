'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { PortfolioItem, FilterCategory, portfolioItems } from '@/data/portfolio'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

const filters: { label: string; value: FilterCategory }[] = [
  { label: 'Wszystkie', value: 'all' },
  { label: 'Montaż Video', value: 'video' },
  { label: 'Grafika', value: 'graphics' },
  { label: 'Animacje', value: 'animation' },
]

export function PortfolioGrid() {
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('all')

  const filteredItems = portfolioItems.filter(
    item => activeFilter === 'all' || item.category === activeFilter
  )

  return (
    <div className="space-y-8">
      {/* Filter Buttons */}
      <div className="flex flex-wrap gap-4 justify-center">
        {filters.map((filter) => (
          <Button
            key={filter.value}
            onClick={() => setActiveFilter(filter.value)}
            variant={activeFilter === filter.value ? "default" : "outline"}
            className={`
              rounded-full px-6 transition-colors duration-300
              ${activeFilter === filter.value 
                ? 'bg-blue-500 text-white hover:bg-blue-600' 
                : 'bg-transparent border-gray-700 text-gray-400 hover:bg-gray-800 hover:text-gray-300'
              }
            `}
          >
            {filter.label}
          </Button>
        ))}
      </div>

      {/* Portfolio Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredItems.map((item) => (
            <motion.div
              key={item.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.3 }}
            >
              <Link href={item.videoUrl || '#'} target={item.videoUrl ? "_blank" : "_self"}>
                <Card className="group relative overflow-hidden rounded-xl bg-gray-900/50 backdrop-blur-lg border border-gray-800 cursor-pointer">
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.3 }}
                    className="aspect-video relative overflow-hidden"
                  >
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="absolute bottom-0 left-0 right-0 p-4">
                        <h3 className="text-lg font-semibold text-white">
                          {item.title}
                        </h3>
                        {item.description && (
                          <p className="text-sm text-gray-300 mt-1">
                            {item.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </motion.div>
                </Card>
              </Link>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}

