import { Inter } from 'next/font/google'
import { Header } from './header'
import { Footer } from './footer'

const inter = Inter({ subsets: ['latin', 'latin-ext'] })

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className={`min-h-screen bg-gradient-to-b from-gray-900 to-black ${inter.className}`}>
      <div className="mx-auto max-w-screen-2xl px-4 sm:px-6 lg:px-8">
        <Header />
        <main>{children}</main>
        <Footer />
      </div>
    </div>
  )
}

