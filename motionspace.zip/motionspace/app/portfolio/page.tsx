import { Layout } from '@/components/layout'
import { PortfolioGrid } from '@/components/portfolio-grid'

export default function PortfolioPage() {
  return (
    <Layout>
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Nasze Projekty
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Zobacz nasze najlepsze prace z zakresu montażu wideo, grafiki i animacji
            </p>
          </div>

          <PortfolioGrid />
        </div>
      </section>
    </Layout>
  )
}

