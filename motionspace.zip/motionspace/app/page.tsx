import { Layout } from '@/components/layout'
import { Hero } from '@/components/hero'
import { TeamSection } from '@/components/team-section'

export default function Home() {
  return (
    <Layout>
      <Hero />
      <TeamSection />
    </Layout>
  )
}

