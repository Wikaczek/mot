export interface PortfolioItem {
  id: string
  title: string
  image: string
  category: 'video' | 'graphics' | 'animation'
  description?: string
  videoUrl?: string
}

export const portfolioItems: PortfolioItem[] = [
  {
    id: '1',
    title: 'Minecraft Character Animation',
    image: '/portfolio/minecraft.jpg',
    category: 'animation',
    description: 'Custom character animation for gaming content',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'
  },
  {
    id: '2',
    title: 'Project 2',
    image: '/portfolio/project2.jpg',
    category: 'video',
    description: 'Video editing showcase',
    videoUrl: 'https://vimeo.com/148751763'
  },
  {
    id: '3',
    title: 'Project 3',
    image: '/portfolio/project3.jpg',
    category: 'graphics',
    description: 'Graphic design work'
  },
  // Add more items as needed
]

export type FilterCategory = 'all' | 'video' | 'graphics' | 'animation'

