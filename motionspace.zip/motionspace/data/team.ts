export interface TeamMember {
  id: string
  name: string
  role: string
  image: string
  color: string
  socialLinks?: {
    discord?: string
    behance?: string
    instagram?: string
  }
}

export const teamMembers: TeamMember[] = [
  {
    id: '1',
    name: 'Fluxerrr',
    role: 'Senior Video Editor, Graphic Designer',
    image: '/team/fluxerrr.jpg',
    color: '#8c4bff',
    socialLinks: {
      discord: '#',
      behance: '#'
    }
  },
  {
    id: '2',
    name: 'Witkopo',
    role: 'Senior Video Editor, Graphic Designer',
    image: '/team/witkopo.jpg',
    color: '#00c7ff',
    socialLinks: {
      instagram: '#',
      behance: '#'
    }
  },
  {
    id: '3',
    name: 'Wolne miejsce',
    role: 'Motion Designer, Graphic Designer',
    image: '/discord-placeholder.png',
    color: '#ff3998',
    socialLinks: {
      discord: '#'
    }
  }
]

